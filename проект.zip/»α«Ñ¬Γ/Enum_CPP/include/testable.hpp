
#include <string>
#include <iostream>

// Created as a base class for all classes which are going to be tested
// requires methods fromString and toString and overloads << and >> for both
class Testable
{
public:
    virtual void fromString(const std::string &s) = 0;
    virtual std::string toString() const = 0;

    friend std::ostream &operator<<(std::ostream &os, const Testable &t);
    friend std::istream &operator>>(std::istream &is, Testable &t);
};