#include "testable.hpp"
#include <boost/algorithm/string.hpp>
#include <boost/bimap.hpp>
#include <vector>
#include <string>

enum class Suit
{
    Hearts,
    Diamonds,
    Clubs,
    Spades
};

enum class Value
{
    _6,
    _7,
    _8,
    _9,
    _10,
    Jack,
    Queen,
    King,
    Ace
};

typedef boost::bimap<std::string, Suit> suits_t;
typedef suits_t::value_type suits_position;
typedef boost::bimap<std::string, Value> values_t;
typedef values_t::value_type values_position;

// suits_t suits = {
//     {"Hearts", Suit::Hearts},
//     {"Diamonds", Suit::Diamonds},
//     {"Clubs", Suit::Clubs},
//     {"Spades", Suit::Spades},
// };

values_t values;
values.insert(values_position("6", Value::_6));
values.insert(values_position("7", Value::_7));
values.insert(values_position("8", Value::_8));
values.insert(values_position("9", Value::_9));
values.insert(values_position("10", Value::_10));
values.insert(values_position("Jack", Value::Jack));
values.insert(values_position("Queen", Value::Queen));
values.insert(values_position("King", Value::King));
values.insert(values_position("Ace", Value::Ace));

class Card : public Testable
{
public:
    Card()
        : Card(Suit::Hearts, Value::_6) {}
    Card(Suit s, Value v)
        : s_(s), v_(v) {}

    void fromString(const std::string &s) override;
    std::string toString() const override;

private:
    Suit s_;
    Value v_;
};