/*
1) Створіть та реалізуйте за допомогою перерахування базові функції
вводу-виводу для наступних сутностей:
a) день тижня;
b) місяць у році;
c) колір спектру;
d) шахова фігура.
*/

#include "testable.hpp"
#include <string>

// is represented the same way for every class
enum class WeekdayEnum
{
    Sun,
    Mon,
    Tue,
    Wed,
    Thu,
    Fri,
    Sat
};

class Weekday : public Testable
{
public:
    Weekday()
        : Weekday(WeekdayEnum::Sun) {}
    explicit Weekday(unsigned short wdi)
        : wdi_(wdi), wd_((WeekdayEnum)wdi){};
    explicit Weekday(WeekdayEnum wd)
        : wdi_((unsigned short)wd), wd_(wd){};

    void fromString(const std::string &s) override;
    std::string toString() const override;

private:
    WeekdayEnum wd_;
    unsigned short wdi_;
};