
#include <string>

enum class WeekdayEnum
{
    Sun,
    Mon,
    Tue,
    Wed,
    Thu,
    Fri,
    Sat
};

class Weekday
{
public:
    explicit Weekday(unsigned short wdi)
        : wdi_(wdi), wd_((WeekdayEnum)wdi){};
    explicit Weekday(WeekdayEnum wd)
        : wdi_((unsigned short)wd), wd_(wd){};

    static Weekday fromString(const std::string &s)
    {
    }

    std::string toString()
    {
    }

private:
    WeekdayEnum wd_;
    unsigned short wdi_;
};