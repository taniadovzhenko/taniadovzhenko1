#include "weekday.hpp"

void Weekday::fromString(const std::string &s)
{
    if (s == "Sun" || s == "0")
        *this = Weekday(0);
    else if (s == "Mon" || s == "1")
        *this = Weekday(1);
    else if (s == "Tue" || s == "2")
        *this = Weekday(2);
    else if (s == "Wed" || s == "3")
        *this = Weekday(3);
    else if (s == "Thu" || s == "4")
        *this = Weekday(4);
    else if (s == "Fri" || s == "5")
        *this = Weekday(5);
    else if (s == "Sat" || s == "6")
        *this = Weekday(6);
}

std::string Weekday::toString() const
{
    switch (wd_)
    {
    case WeekdayEnum::Sun:
        return "Sun";
    case WeekdayEnum::Mon:
        return "Mon";
    case WeekdayEnum::Tue:
        return "Tue";
    case WeekdayEnum::Wed:
        return "Wed";
    case WeekdayEnum::Thu:
        return "Thu";
    case WeekdayEnum::Fri:
        return "Fri";
    case WeekdayEnum::Sat:
        return "Sat";

    default:
        return "NotAWeekDay";
    }
}
