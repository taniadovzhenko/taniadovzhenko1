#include "testable.hpp"

std::ostream &operator<<(std::ostream &os, const Testable &t)
{
    os << t.toString();
    return os;
}

std::istream &operator>>(std::istream &is, Testable &t)
{
    std::string s;
    is >> s;

    t.fromString(s);
    return is;
}