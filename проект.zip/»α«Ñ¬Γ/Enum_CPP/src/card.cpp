#include "card.hpp"

void Card::fromString(const std::string &s)
{
    std::vector<std::string> splitted;
    boost::split(splitted, s, boost::is_any_of(" "));

    Suit s = suits.left[splitted[0]];
    Value v = values.left[splitted[1]];
}

std::string Card::toString() const
{
    return suits.right[s_] + " " + suits.right[v_];
}
