#ifndef TEST_LOADER_HPP
#define TEST_LOADER_HPP

#include <nlohmann/json.hpp>
#include <fstream>

using nlohmann::json;

const std::string fname = "test/Enum_test.json";

auto loadTest(const std::string &testname)
{
    std::ifstream ifs(fname);
    if (!ifs.is_open())
    {
        std::cerr << "Test file was not opened!" << std::endl;
        std::exit(1);
    }
    std::string content((std::istreambuf_iterator<char>(ifs)),
                        (std::istreambuf_iterator<char>()));

    auto jsonContents = json::parse(content);
    return jsonContents[testname];
}

#endif