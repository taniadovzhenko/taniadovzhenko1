#include <iostream>
#include "loader.hpp"
#include "weekday.hpp"

int main()
{
    auto tests = loadTest("weekday");
    for (auto &test : tests)
    {
        Weekday wd;
        wd.fromString(test);
        std::cout << wd << std::endl;
    }

    return 0;
}